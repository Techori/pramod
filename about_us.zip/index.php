<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shree Unnati Wires & Traders - Premium Wire Manufacturing</title>
    <meta name="description" content="Leading manufacturer of high-quality copper and aluminum wires for industrial, commercial, and residential applications. Explore our range of quality-assured products.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <style>
        /* Basic CSS for layout and button styling */
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            line-height: 1.6;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        /* Header Styles */
        /* .site-header {
            background-color: #e3f2fd; // Changed to a lighter blue color 
            padding: 1rem 0;
            border-bottom: 1px solid #eee;
        }
        .site-header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            height: 50px; // Adjust logo height as needed 
            margin-right: 15px;
        }
        .logo h1 {
            margin: 0;
            font-size: 1.5rem;
            color: #007bff; // Changed back to the original blue color 
        }
        .main-navigation ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
        }
        .main-navigation li {
            margin-left: 20px;
        }
        .main-navigation a {
            text-decoration: none;
            color: #555; // Changed back to the original dark gray color
            transition: color 0.3s ease;
            padding: 8px 12px; // Add padding for better click area 
            border-radius: 5px; // Optional: round the links 
        }
        .main-navigation a:hover {
            color: #007bff;
            background-color: #b0e0e6; // Slight background change on hover for better feedback 
        } */
        /* Hero Section */
        .hero-section {
            padding: 4rem 0;
            text-align: center;
            background-color: #f0f8ff;
        }
        .hero-title {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #222;
        }
        .hero-subtitle {
            font-size: 1.2rem;
            color: #555;
            margin-bottom: 2rem;
        }
        .hero-buttons {
            display: flex;
            justify-content: center;
            gap: 1rem;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.1s ease;
            cursor: pointer; /* Indicate it's clickable */
            border: none; /* Remove default button border */
            font-size: 1rem;
        }
        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }
        .btn-primary:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }
        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
        .btn-secondary:hover {
            background-color: #5a6268; /* Darker shade on hover */
        }
        .btn:hover {
            transform: scale(1.05); /* Slight scale-up on hover */
        }
        .btn:active {
            transform: scale(0.95); /* Slight scale-down on click */
        }
        .hero-stats {
            display: flex;
            justify-content: space-around;
            margin-top: 3rem;
            text-align: center;
        }
        .hero-stat {
            padding: 1rem;
        }
        .hero-stat strong {
            display: block;
            font-size: 2rem;
            color: #007bff;
        }
        .hero-stat span {
            color: #777;
        }
        /* Features Section */
        .features-section {
            padding: 4rem 0;
            background-color: #fff;
        }
        .section-title {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 2rem;
            color: #222;
        }
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        .feature-item {
            background-color: #f9f9f9;
            padding: 1.5rem;
            border-radius: 5px;
            text-align: center;
            border: 1px solid #eee;
        }
        .feature-item h3 {
            margin-top: 0;
            color: #333;
        }
        .feature-item p {
            color: #666;
        }
        /* Testimonials Section */
        .testimonials-section {
            padding: 4rem 0;
            background-color: #f0f8ff;
        }
        .testimonial-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        .testimonial-item {
            background-color: #fff;
            padding: 1.5rem;
            border-radius: 5px;
            font-style: italic;
            border: 1px solid #ddd;
        }
        .testimonial-item p:last-child {
            font-style: normal;
            margin-top: 1rem;
            font-weight: bold;
            color: #555;
        }
        .testimonial-item span {
            display: block;
            font-weight: normal;
            font-style: normal;
            color: #777;
        }
        /* Contact Section */
        .contact-section {
            padding: 4rem 0;
            background-color: #fff;
        }
        .contact-wrapper {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }
        .contact-info {
            padding: 1.5rem;
            background-color: #f9f9f9;
            border-radius: 5px;
            border: 1px solid #eee;
        }
        .contact-info h3 {
            color: #333;
        }
        .contact-info p {
            color: #666;
        }
        .contact-info a {
            color: #007bff;
            text-decoration: none;
        }
        .contact-info a:hover {
             color: #0056b3; /* Darker shade on hover */
        }
        .contact-form {
            padding: 1.5rem;
            background-color: #f9f9f9;
            border-radius: 5px;
            border: 1px solid #eee;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #444;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="tel"],
        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 1rem;
        }
        .form-group button {
            background-color: #007bff;
            color: #fff;
            padding: 1rem 2rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }
        .form-group button:hover {
            background-color: #0056b3;
            transform: scale(1.02);
        }
        .form-group button:active {
            transform: scale(0.98);
        }
    </style>
</head>
<body>
    <?php
        include('./_main_nav.php');
    ?>
    <main>
        <section class="hero-section">
            <div class="container">
                <h1 class="hero-title">Premium Wire Manufacturing</h1>
                <p class="hero-subtitle">Leading manufacturer of high-quality copper and aluminum wires for industrial, commercial and residential applications</p>
                <div class="hero-buttons">
                    <a href="#" class="btn btn-primary" onclick="showAlert('Explore Our Products')">Explore Our Products</a>
                    <a href="#" class="btn btn-secondary" onclick="showAlert('Contact Us')">Contact Us</a>
                </div>
                <div class="hero-stats">
                    <div class="hero-stat">
                        <strong>25+</strong>
                        <span>Years Experience</span>
                    </div>
                    <div class="hero-stat">
                        <strong>500+</strong>
                        <span>Products</span>
                    </div>
                    <div class="hero-stat">
                        <strong>50+</strong>
                        <span>Distributors</span>
                    </div>
                    <div class="hero-stat">
                        <strong>100%</strong>
                        <span>Quality Assured</span>
                    </div>
                </div>
            </div>
        </section>

        <section class="features-section">
            <div class="container">
                <h2 class="section-title">Industry-Leading Wire Manufacturing</h2>
                <p style="text-align: center; margin-bottom: 2rem; color: #555;">Discover what makes Unnati Wires the preferred choice for quality electrical wires across sectors</p>
                <div class="features-grid">
                    <div class="feature-item">
                        <h3>Superior Insulation</h3>
                        <p>Our wires feature high-grade PVC and XLPE insulation for maximum safety and durability in all environments.</p>
                    </div>
                    <div class="feature-item">
                        <h3>High Conductivity</h3>
                        <p>Premium grade copper ensures excellent electrical conductivity and energy efficiency for optimal performance.</p>
                    </div>
                    <div class="feature-item">
                        <h3>ISO Certified</h3>
                        <p>All our manufacturing processes and products are ISO 9001:2015 certified for quality assurance and reliability.</p>
                    </div>
                    <div class="feature-item">
                        <h3>Modern Manufacturing</h3>
                        <p>State-of-the-art production facilities with advanced machinery for precision wire drawing and quality control.</p>
                    </div>
                    <div class="feature-item">
                        <h3>Quality Testing</h3>
                        <p>Rigorous testing at every production stage ensures our wires meet the highest industry standards and specifications.</p>
                    </div>
                    <div class="feature-item">
                        <h3>Nationwide Distribution</h3>
                        <p>Extensive distribution network ensuring timely delivery and consistent supply across the country.</p>
                    </div>
                    <div class="feature-item">
                        <h3>Customization Options</h3>
                        <p>Custom wire solutions available based on specific requirements for industrial and commercial applications.</p>
                    </div>
                    <div class="feature-item">
                        <h3>Temperature Resistant</h3>
                        <p>Our wires maintain performance integrity even under extreme temperature conditions and harsh environments.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="testimonials-section">
            <div class="container">
                <h2 class="section-title">Trusted by Industry Leaders</h2>
                <p style="text-align: center; margin-bottom: 2rem; color: #555;">Hear from professionals who rely on our high-quality wires for their critical electrical projects</p>
                <div class="testimonial-grid">
                    <article class="testimonial-item">
                        <p>"Unnati Wires has been our trusted supplier for over a decade. Their copper wires offer exceptional conductivity and have proven to be highly reliable for our electrical installations."</p>
                        <p><strong>Rajesh Sharma</strong><br><span>Chief Procurement Officer, Electro Solutions Ltd.</span></p>
                    </article>
                    <article class="testimonial-item">
                        <p>"The quality control at Unnati is remarkable. Every batch of wires we've received meets the exact specifications and industry standards. Their flame-retardant insulation is the best in the market."</p>
                        <p><strong>Priya Patel</strong><br><span>Production Manager, PrimeTech Industries</span></p>
                    </article>
                    <article class="testimonial-item">
                        <p>"As a distributor of electrical products, I can confidently say that Unnati Wires are among our best-selling items due to their consistent quality and competitive pricing."</p>
                        <p><strong>Vikram Singh</strong><br><span>Managing Director, Singh Electrical Distributors</span></p>
                    </article>
                </div>
            </div>
        </section>

        <section class="contact-section">
            <div class="container">
                <h2 class="section-title">Get in Touch</h2>
                <p style="text-align: center; margin-bottom: 2rem; color: #555;">Contact us to learn more about our products, services, or our business management system. We're here to support your business needs.</p>
                <div class="contact-wrapper">
                    <div class="contact-info">
                        <h3>Contact Information</h3>
                        <p><strong>Phone:</strong> +91 98765 43210</p>
                        <p><strong>Email:</strong> <a href="mailto:info@unnatitraders.com" onclick="showAlert('Email: info@unnatitraders.com')">info@unnatitraders.com</a></p>
                        <p><strong>Location:</strong> 123 Industrial Area, Business District, City - 123456</p>
                        <p><a href="#" onclick="showAlert('Visit Contact Page')">Visit Contact Page</a></p>
                    </div>
                    <div class="contact-form">
                        <h3>Quick Inquiry</h3>
                        <form onsubmit="showAlert('Inquiry Submitted'); return false;">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" id="phone" name="phone">
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea id="message" name="message" rows="5"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Submit Inquiry</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php
        include('./_footer.php');
    ?>
    <script>
        function showAlert(buttonName) {
            alert(`You clicked the "${buttonName}" button/link! This functionality would be implemented with further development to navigate to different pages or perform specific actions.`);
        }
    </script>

</body>
</html>
