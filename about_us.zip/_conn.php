<?php
    $host="localhost";
    $user="u276201717_unnati_traders";
    $password="Unn@t1_traders";
    $dbname="u276201717_unnati_wires";
    date_default_timezone_set("Asia/Kolkata");
    
    $conn = new mysqli($host, $user, $password, $dbname)
    or die ('Could not connect to the database server' . mysqli_connect_error());